
/*we used chat.gpt it gave us a rudimentary code which we modified to fit the game needs*/
// Get the tink element
const tink = document.getElementById('tink');

// Set the initial position
let position = 0;
let direction = 1; // 1 for moving right, -1 for moving left

// Adjust the speed (reduce the value to make it slower)
const speed = 1;


/* Calculating and displaying score on page load
Reference = https://www.w3schools.com/jsref/event_onload.asp*/

window.onload = function(){
  let percent = localStorage.getItem('percent');
  console.log(percent);
  document.getElementById('score').innerHTML = 'You scored: ' + percent + '%';
}

// Function to move the tink
function moveTink() {
  // Update the position
  position += speed * direction; // Adjust the speed as needed

  // Check if the tink is at the edge of the screen
  if (position >= window.innerWidth - tink.width || position <= 0) {
    // Change direction when reaching the edge
    direction *= -1;
  }

  // Update the tink's position
  tink.style.left = position + 'px';

  // Repeat the movement
  requestAnimationFrame(moveTink);
}

// Start the movement
moveTink();