/*we used chat.gpt it gave us a rudimentary code which we modified to fit the game needs*/
//Through this, we are able to add an eventlistener which helps us determine when to statrt the animation
//which in this case is when the DOM (Document Object Model) is loaded, which helps launch the initial HTML
//page even if it completely parsed and loaded (whihc means that images might load a little later and this is executed before it.)

document.addEventListener("DOMContentLoaded", function () {
    // Get the crocodile and tink elements
    const tink = document.getElementById('tink');
    const crocodile = document.getElementById('crocodile');

    // Set the initial positions and directions
    let tinkPosition = 0;
    let tinkDirection = 1; // 1 for moving right

    let crocodilePosition = window.innerWidth - crocodile.width;
    let crocodileDirection = -1; // -1 for moving left

    // Adjust the speeds
    const tinkSpeed = 1;
    const crocodileSpeed = 1;

    // Function to move tink and crocodile
    function moveElements() {
        tinkPosition += tinkSpeed * tinkDirection;
        crocodilePosition += crocodileSpeed * crocodileDirection;

        //Avoids Tink and Crocky to go off screen and helps it move backwards to reach the other side of the screen
        //one step at a time. 
        if (tinkPosition >= window.innerWidth - tink.width || tinkPosition <= 0) {
            tinkDirection *= -1; //Moves Tink backwards
        }

        if (crocodilePosition >= window.innerWidth || crocodilePosition <= -crocodile.width) {
            crocodileDirection *= -1;//Moves Crocky backwards
        }

        tink.style.left = tinkPosition + 'px'; //Helps move Tink according to the speed and position calculated previously
        crocodile.style.left = crocodilePosition + 'px';//Helps move Crocky according to the speed and position calculated previously

        requestAnimationFrame(moveElements);//Helps tell the browser that an animation is supposed to be done in this HTML page. 
    }

    // Start the movement
    moveElements();
});
