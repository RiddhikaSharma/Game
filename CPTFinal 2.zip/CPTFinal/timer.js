//Inspired from Mr. DeRuiter's timer code that was given in class. 

let timer;
let duration = 10; // 1 minute 30 seconds in seconds

function updateTimerDisplay() {
    const timerElement = document.getElementById('timer');

    // Calculate minutes and seconds without using padStart
    const minutesTimer = Math.floor(duration / 60);
    const secondsTimer = duration % 60;

    // Construct the time string manually with zero padding (used generative AI to come up with this segment of code)
    const timeString = formatTime(minutesTimer) + ':' + formatTime(secondsTimer);

    /*This helps determine the fact that all of elements in timerElement are for formatting purposes only and do not have 
    any other function.*/
    timerElement.textContent = timeString;

    if (duration == 60) {
        timerElement.classList.add('timer-red');
    }

    if (duration ===0) {
        clearInterval(timer);
        timerComplete();
    } else {
        duration--;
    }
}

// Function to manually add zero padding (used generative AI to come up with this segment of code)
function formatTime(time) {
    return time < 10 ? '0' + time : time.toString();
}

function timerComplete() {
    let questionsAttempted = localStorage.getItem('questionsAttempted');
    
    if (questionsAttempted <= 4) {
        window.location.href = 'playAgain.html';
        return;
    }
    alert("You are out of time! Calculating your score");
    let percent = Number(score / questionCounter * 100).toFixed(2);
    console.log(percent);
    localStorage.setItem('percent', percent);
    let tinkLocation = localStorage.getItem('tinkLocation');
    if (tinkLocation >= 600) {
        window.location.href = 'tinkLost.html';
    } else {
        window.location.href = 'tinkWon.html';
    }
}

// Update the timer display immediately when the page loads
updateTimerDisplay();

// Start the timer
timer = setInterval(updateTimerDisplay, 1000);