/*we used chat.gpt it gave us a rudimentary code which we modified to fit the game needs*/
// Get the crocodile element
const crocodile = document.getElementById('crocodile');

// Set the initial position
let position = 0;
let direction = 1; // 1 for moving right, -1 for moving left

/* Calculating and displaying score on page load
Reference = https://www.w3schools.com/jsref/event_onload.asp*/

window.onload = function(){
  let percent = localStorage.getItem('percent');
  console.log(percent);
  document.getElementById('score').innerHTML = 'You scored: ' + percent + '%';
}

// Function to move the crocodile
function moveCrocodile() {
  // Update the position
  position += 2* direction; // Adjust the speed as needed

  // Check if the crocodile is at the edge of the screen
  if (position >= window.innerWidth - crocodile.width || position <= 0) {
    // Change direction when reaching the edge
    direction *= -1;
  }

  // Update the crocodile's position
  crocodile.style.left = position + 'px';

  // Repeat the movement
  requestAnimationFrame(moveCrocodile);
}

// Start the movement
moveCrocodile();

