/*This is where all the game play is controlled, including score calculation, moving Tink, 
checking the answers, etc. All of this is accomplished through the usage of multiple arrays and functions. */

var currentLocation = 300; //This is the initial location which will be updated when the user starts answering questions. 
let score = 0; //Helps keep track of the score (No negative marking!) 
let dangerLocation = 490; //This helps determine the location of the danger zone and it is used to prompt the user when they are in danger. 

const question = document.querySelector(".question-text");
/*Benefit: helps select an element based on a CSS selector while getElementById only select based on the id. 
                                                           We are using class in our case, enabling us to use it multiple times*/
const questionBox = document.querySelector(".question-box");
const answers = document.querySelector(".options");
const option1 = document.querySelector(".option-1");
//Helps to change the question through changing the value shown on the screen when the next question is loaded.
var label = document.getElementsByTagName("label");
//This is an array of the radio buttons that are used to answer the questions. This way, it is easier to access them. 
let radio = [document.getElementById("rad0"),
    document.getElementById("rad1"),
    document.getElementById("rad2"),
    document.getElementById("rad3")
];
//This is the button that enables the user to go to the next question. Additionally, this will also function as the check button.
const button = document.querySelector('.next');
//This calls the image present in the HTML file which enabled us to switch Tink based on the selection in the chooseFairy HTML page. 
let image = document.getElementById("tink");
//This is the questionBank that is filled according to the difficulty level chosen. 
let questionBank = [];
//Counts the number of questions answered in order to calculate the corrent score. 
let questionCounter = 0;
//Store the current question. 
let currentQuestion;
//Stores the options available(the answers) for the questions in this array. 
let availableOptions = [];
//This stores the questions that are left. 
let questionsAvailable = [];
//Helps go to the next question based in the array. 
let qIndex = 0;
//Stores the number of maximum options for a questions. 
let maxOptions = 4;
var answerSelected = -1; //If no answer is selected, the value of answerSelected is set to -1, which means they got it wrong. 


//Local storage for selecting the tink avatar
function changeTinkImage() {
    //Gets the selected Radio Button
    const selectedAvatar = document.querySelector('input[name="selection"]:checked');
    //Uses localStorage to store the value that has been selected by the user.
    localStorage.setItem('selectedTink', selectedAvatar.value);
    if (selectedAvatar) {
        // Redirect to the next HTML page
        window.location.href = 'gamePlay.html';
    } else {
        //If no answer is selected, this prompt is shown. However, it is coded to have an option selected by default. This is just
        //for a precaution. 
        alert('Please select an avatar.');
    }
}

//Helps change the value of the button and helps change the functioning of the button from check to next and vice versa. 
function decideValue() {
    const selected = document.getElementById('change-color');
    let state = selected.value; //Gets the state that is obtained from the button above. 
    if (state == "submit") {
        //Make sure an answer has been selected
        if (checkAnswer() == false) {
            alert("Please choose an answer!");
            return;
        }
        //Changes the text of the button
        document.getElementById('change-color').textContent = "Next";
        //Change the value of the button
        selected.value = "next";
    } else {
        //Change the value of the button
        selected.value = "submit";
        //Changes the text of the button
        document.getElementById('change-color').textContent = "Submit";
        callNextQuestion();
        //The answerSelected value goes back to -1 in order to remove any selection of the radio buttons. 
        answerSelected = -1;
    }
}

//Local storage for getting the selection from the dropdown menu
function getDifficultyLevel() {
    let index = 0;
    //Calls the dropdown menu by calling the class difficultyLevel in order to get the valiue of the difficulty chosen.
    selectElement = document.querySelector('#difficultyLevel');
    output = selectElement.value;
    //Sets the value of the integer index which helps set the valeu of the index that will be used to get the 
    //array value from questions.js
    document.querySelector('.output').textContent = output;
    if (output == "Easy") {
        index = 0;
    } else if (output == "Intermediate") {
        index = 2;
    } else if (output == "Expert") {
        index = 1;
        console.log(scienceQuestions[index]);
    }
    localStorage.setItem('selectedLevel', index);
}

/*This is a type of shuffling, Fisher and Yates' original method. 
Used this for learning this shuffle: https://www.geeksforgeeks.org/shuffle-a-given-array-using-fisher-yates-shuffle-algorithm/*/
function shuffle(inputArray) {
    for (let i = inputArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [inputArray[i], inputArray[j]] = [inputArray[j], inputArray[i]];
    }
    return inputArray;
}

/*This method is to help tranfer the questions in the questionLeft array*/
function availableQuestions() {
    const totalQuestions = questionBank.length;
    for (let i = 0; i < questionBank.length; i++) {
        questionsAvailable[i] = questionBank[i];
    }
    //Calls the shuffle function in order to shuffle all the questions
    shuffle(questionsAvailable);
}

/*This helps get new questions and avoid repetition*/
function getNewQuizQuestions() {
    currentQuestion = questionsAvailable[qIndex++];
    //This ensurest that there is something in currentQuestion and question. 
    if (currentQuestion != null && currentQuestion.question != null && question != null) {
        question.innerHTML = currentQuestion.question; // calls the qusetions in the question.js file
        for (let i = 0; i < maxOptions; i++) {
            //Fills in the option label in the HTML and display all the options. 
            label[i].innerHTML = currentQuestion.options[i];
        }
        questionCounter++;
        //This allows the CSS class of this element. 
        questionBox.classList.add('question-box');
    }
}

//This calls for the next question
function callNextQuestion() {
    //An array of all the options available in the HTML.
    let radioAnswers = [document.querySelector('.option-1'),
        document.querySelector('.option-2'),
        document.querySelector('.option-3'),
        document.querySelector('.option-4')
    ];

    //Cancels any selection made in the radio button when showing the next question. 
    for (let i = 0; i < radioAnswers.length; i++) {
        //Changing the background color to make it look neutral grey
        radioAnswers[i].style.backgroundColor = "#e5e5e5";
        radio[i].disabled = false;
    }

    //When all the questions have been exhausted, a temporary score is shown while loading the next page. 
    if (questionCounter == scienceQuestions[0].length) {
        question.innerHTML = score + "/" + questionCounter;
        answers.innerHTML = "";
    } else {
        getNewQuizQuestions();
    }
}

//This creates the change color effect to show the right and wrong answer while also checking whether the selection is right or wrong. 
function checkAnswer() {
    // Get the selected radio button
    var selectedRadioButton = document.querySelector('input[name="radAnswer"]:checked');
    let radioAnswers = [document.querySelector('.option-1'),
        document.querySelector('.option-2'),
        document.querySelector('.option-3'),
        document.querySelector('.option-4')
    ];

    //Checks whether an option is selected.
    for (let i = 0; i < maxOptions; i++) {
        if (radio[i].checked == true) {
            answerSelected = i;
            radio[i].checked = false;
            break; //breaks the for loop as soon as answer is obtained
        }
    }

    if (answerSelected == -1) {
        return false;
    }

    //Changes the background color as soon as an answer is obtained. 
    for (let i = 0; i < radioAnswers.length; i++) {
        if (currentQuestion.answer == i) {
            radioAnswers[i].style.backgroundColor = "#90d698";
        } else {
            radioAnswers[i].style.backgroundColor = "#ffb3b2";
        }
        //disable all the radio buttons for the duration. 
        radio[i].disabled = true;
    }

    //If the person selects the right option, the score is increased, questionCounter is increased, and Tink is moved one step to the left. 
    if (answerSelected == currentQuestion.answer) {
        score++;
        questionCounter + 1;
        movingTinkLeft();
    } else {
        //If the person selected the wrong option, only questionCounter is increased, and Tink is moved one step to the right. 
        movingTinkRight();
        questionCounter + 1;
    }
    //Uses localStorage to store these items in order to show in the end pages. 
    localStorage.setItem('score', score);
    localStorage.setItem('questionsAttempted', questionCounter);
    return true;
}

/*since we need the questions to start as soon as the user loads the window, we have to use the onload feature
Reference = https://www.w3schools.com/jsref/event_onload.asp*/

window.onload = function() {
    let difficultyLevel = localStorage.getItem('selectedLevel');
    if (difficultyLevel == null || difficultyLevel < 0) {
        questionBank = scienceQuestions[0]; //set default
    } else {
        questionBank = scienceQuestions[difficultyLevel];
    }
    availableQuestions();
    getNewQuizQuestions();
    if (document.getElementById("tink") != null) {
        document.getElementById("tink").src = localStorage.getItem('selectedTink');
    }
}

/*This function allows us to move Tink based on what the user inputs. When answered wrong*/
function movingTinkRight() {
    //Moves tink by 55px to the right
    currentLocation += 55;
    //Checks when Tink reaches the end of the plank. 
    if (currentLocation >= 600) {
        currentLocation = 300;
        //Calculates the percentages. 
        let percent = Number(score / questionCounter * 100).toFixed(2);
        //Uses localStorage in order to send the percentage to the end pages.
        localStorage.setItem('percent', percent);
        window.location.href = 'tinkLost.html';
    } else if (currentLocation > 490 && currentLocation < 540) { //prompts the user to start paying attention when they have entered the danger zone for when
        // two and one questions are left. 
        displayWarning("You are in the danger zone! You only have two more questions to save Tink from getting eaten!");
    } else if (currentLocation > 540) {
        displayWarning("You are in the danger zone! You only have one more question to save Tink from getting eaten!");
    }
    var newLocation = currentLocation.toString() + "px";
    document.getElementById("tink").style.left = newLocation;
    localStorage.setItem('tinkLocation', currentLocation);
}

//When the answer is answered right
function movingTinkLeft() {
    ////Moves tink by 55px to the left
    currentLocation -= 55;
    if (currentLocation <= 300) {
        currentLocation = 300;
    }
    var newLocation = currentLocation.toString() + "px";
    document.getElementById("tink").style.left = newLocation;
    localStorage.setItem('tinkLocation', currentLocation);
}

//For displaying the prompts when the user enters the danger zone. 
function displayWarning(message) {
    const warningDiv = document.createElement('div');
    warningDiv.className = 'warning';
    warningDiv.textContent = message;
    alert(message);
}