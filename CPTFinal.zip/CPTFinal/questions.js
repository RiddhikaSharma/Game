//This makes it easier to see which one is the answer, questions, and the options
/*It includes a string, which is assigned to the value q, an array of options, and an index that determines which option is correct 
(these are properties).
The curly braces are used with the purpose to create an object of one question, answer, and the options. 
Since we don't need to know the length of the string of the questions or the options, it is better to use these curly braces.*/ 
/*Reference for understanding how to make an array consisting of multiple things: https://sabe.io/blog/javascript-arrays-brackets-braces*/
//https://www.gktoday.in/quizbase/general-science-for-competitive-examinations?pageno=5 for the questions

const scienceQuestions = [ [
    {
        question: 'What is the PH of H2O?',
        options: ['6', '7', '8', '9'],
        answer: 1,
    },
    {
        question: 'Which of the following compound is mainly used in hand sanitizer?',
        options: ['Aldehyde', 'Acetic acid', 'Alcohol', 'Ketone'],
        answer: 2,
    },
    {
        question: 'What is the color of AgBr?',
        options: ['Blue', 'Brown', 'White', 'Yellow'],
        answer: 2,
    },
    {
        question: "What is the other name of Newton's first law of motion?",
        options: ['Action-reaction', 'Change in momentum', 'Law of inertia', 'Constant momentum'],
        answer: 2,
    },
    {
        question: "According to Newton's second law of motion, change in momentum per unit time is equal to ________.",
        options: ['Force', 'Energy', 'Acceleration', 'Work'],
        answer: 0,
    },
    {
        question: 'What is the color of SO2 gas?',
        options: ['Blue', 'Grey', 'Colorless', 'Brown'],
        answer: 2,
    },
    {
        question: 'What is the color of CuSO4?',
        options: ['Blue', 'Brown', 'Orange', 'White'],
        answer: 0,
    },
    {
        question: 'What is the S.I unit of electric charge?',
        options: ['Coulomb', 'Ampere', 'Faraday', 'Ohm'],
        answer: 0,
    },
    {
        question: 'How many carbon atoms are present in heptane?',
        options: ['6', '7', '8', '5'],
        answer: 1,
    },
    {
        question: 'What is the chemical formula of benzene?',
        options: ['C6H6', 'C6H4', 'C8H6', 'C6H8'],
        answer: 0,
    },
    {
        question: 'What is the atomic number of phosphorus?',
        options: ['12', '13', '14', '15'],
        answer: 2,
    },
    {
        question: 'Which of the following quantity increases in a group when we move from top to bottom?',
        options: ['Valency', 'Electronegativity', 'Atomic size', 'Ionization energy'],
        answer: 2,
    },
    {
        question: 'What is the PH range of acids?',
        options: ['0 - 7', '7 - 14', '1 - 7', '7 - 15'],
        answer: 0,
    },
    {
        question: 'Name the non-metals which have high melting and boiling point?',
        options: ['Gallium', 'Diamond', 'Cesium', 'Lead'],
        answer: 1,
    },
    {
        question: 'Name the metal which is most ductile?',
        options: ['Gold', 'Silver', 'Copper', 'Iron'],
        answer: 1,
    },
    {
        question: 'What is the S.I unit of current?',
        options: ['Coulomb', 'Ampere', 'Ohm', 'Volt'],
        answer: 1,
    },
    {
        question: 'What is the S.I unit of potential difference?',
        options: ['Volt', 'Ampere', 'Coulomb', 'Ohm'],
        answer: 0,
    },
    {
        question: 'Name the veins that carry oxygenated blood from the heart to other parts of the body?',
        options: ['Kidney', 'Arteries', 'Both (a) and (b)', 'None of these'],
        answer: 1,
    },
    {
        question: 'Name the part of the body on which coronavirus affects the most?',
        options: ['Heart', 'Liver', 'Kidney', 'Lungs'],
        answer: 3,
    },
    {
        question: 'Name the part of the eye on which the image is formed?',
        options: ['Cornea', 'Lens', 'Optical nerves', 'Brain'],
        answer: 1,
    },
    {
        question: 'Which of the following diseases is caused by dog bites?',
        options: ['Scurvy', 'Madness', 'Rabies', 'Colorblindness'],
        answer: 2,
    },
    {
        question: 'Which device is used for measuring air pressure?',
        options: ['Ammeter', 'Voltmeter', 'Seismograph', 'Barometer'],
        answer: 3,
    },
    {
        question: 'What is the basic principle of an electric generator?',
        options: ['Law of constant momentum', 'Fleming left-hand rule', "Ohm's law", 'None of these'],
        answer: 1,
    },
    {
        question: 'What is the S.I unit of lens power?',
        options: ['Joule', 'Calorie', 'Diopter', 'Hertz'],
        answer: 2,
    },
    {
        question: 'What is the S.I unit of resistance?',
        options: ['Coulomb', 'Ohm', 'Volt', 'Ampere'],
        answer: 1,
    },
    {
        question: 'What is the chemical formula of alcohol?',
        options: ['C2H5OH', 'C2H5', 'C2H5COOH', 'C2H5O'],
        answer: 0,
    },
    {
        question: 'What is the name of juice secreted from the gall bladder?',
        options: ['Saliva', 'Hydrochloric acid', 'Bile juice', 'Maltase'],
        answer: 2,
    },
    {
        question: 'What is the scientific name of humans?',
        options: ['Mangifera indica', 'Rana tigrina', 'Homo sapiens', 'Homo species'],
        answer: 2,
    },
    {
        question: 'What is the scientific name of frog?',
        options: ['Anura', 'Homo sapiens', 'Felis catus', 'Mangifera indica'],
        answer: 0,
    },
    {
        question: 'What is the name of farming in which the domestication of hens is involved?',
        options: ['Pisci culture', 'Apiculture', 'Poultry culture', 'None of these'],
        answer: 2,
    },
    {
        question: 'Who discovered the x-rays?',
        options: ['Maxwell', 'Wilhelm Roentgen', 'Faraday', 'Hertz'],
        answer: 1,
    },
    {
        question: 'Who discovered radioactivity?',
        options: ['Madam Curie', 'Henri Becquerel', 'Faraday', 'Hertz'],
        answer: 1,
    },
    {
        question: 'Name the process by which the human breathes?',
        options: ['Photosynthesis', 'Digestion', 'Excretion', 'Respiration'],
        answer: 3,
    }
], [
    {
        question: 'The adult human of average age and size has approximately how many quarts of blood? Is it:',
        options: ['4', '6', '8', '10'],
        answer: 1,
    },
    {
        question: 'Once the erythrocytes enter the blood in humans, it is estimated that they have an average lifetime of how many days. Is it:',
        options: ['10 days', '120 days', '200 days', '360 days'],
        answer: 1,
    },
    {
        question: 'Of the following, which mechanisms are important in the death of erythrocytes (pron: eh-rith-reh-sites) in human blood? Is it',
        options: ['phagocytosis (pron: fag-eh-seh-toe-sis)', 'hemolysis', 'mechanical damage', 'all of the above'],
        answer: 3,
    },
    {
        question: 'Surplus red blood cells, needed to meet an emergency, are MAINLY stored in what organ of the human body? Is it the:',
        options: ['pancreas', 'spleen', 'liver', 'kidneys'],
        answer: 1,
    },
    {
        question: 'When a human donor gives a pint of blood, it usually requires how many weeks for the body RESERVE of red corpuscles to be replaced? Is it:',
        options: ['1 week', '3 weeks', '7 weeks', '21 weeks'],
        answer: 2,
    },
    {
        question: 'There are three substances found in human blood which carry oxygen and which begin with the letter "H". Name two of these substances.',
        options: ['Hemoglobin', 'Hemocyanin', 'Hemoglycosis', 'Hemocytosis'],
        answer: 0,
    },
    {
        question: 'The several types of white blood cells are sometime collectively referred to as:',
        options: ['erythrocytes (pron: eh-rith-row-cites)', 'leukocytes (pron: lew-kah-cites)', 'erythroblasts (pron: eh-rith-rah-blast)', 'thrombocytes (pron: throm-bow-cites)'],
        answer: 1,
    },
    {
        question: 'The condition in which there is a DECREASE in the number of white blood cells in humans is known as:',
        options: ['leukocytosis (pron: lew-kO-sigh-toe-sis)', 'leukopenia (pron: lew-kO-pea-nee-ah)', 'leukemia (pron: lew-kee-me-ah)', 'leukohyperia (pron: lew-kO-high-per-e-ah)'],
        answer: 1,
    },
    {
        question: 'The smallest of the FORMED elements of the blood are the:',
        options: ['white cells', 'red cells', 'platelets', 'erythrocytes'],
        answer: 2,
    },
    {
        question: 'Which of the following statements concerning platelets is INCORRECT. Platelets:',
        options: ['contain DNA', 'are roughly disk-shaped', 'have little ability to synthesize proteins', 'are between 1/2 and 1/3 the diameter of the red cell'],
        answer: 0,
    },
    {
        question: 'What is the primary function of the platelets in human blood?',
        options: ['clotting or blocking leaks from blood vessels','transferring oxygen from the lungs to tissues', 'attacking microbess', 'converts lipids to carbohydrates'],
        answer: 0,
    },
    {
        question: 'When a wound occurs in humans, the platelets in the blood activate a substance which starts the clotting process. The substance which starts the clotting is:',
        options: ['adenosine (pron: ah-den-ah-seen)', 'histamine', 'lecithin (pron: less-ah-thin)', 'thrombin'],
        answer: 3,
    },
    {
        question: 'When looking at the cross section of the human tibia, one finds the RED marrow in the:',
        options: ['medullary cavity', 'cancellous bone', 'periosteum', 'epiphysis'],
        answer: 0,
    },
    {
        question: 'Lengthening of long bones in humans occurs in a particular area of the bone. This area is called the:',
        options: ['medullary canal', 'cancellous bone', 'periosteum (pron: per-E-ahs-tee-em)', 'epiphysis (pron: eh-pif-eh-sis)'],
        answer: 3,
    },
    {
        question: 'The part of the human brain which is an important relay station for the sensory impulses and also is the origin of many of the involuntary acts of the eye such as the narrowing of the pupil in bright light is the:',
        options: ['hypothalamus', 'midbrain', 'corpus callosum', 'cerebellum'],
        answer: 1,
    },
    {
        question: 'In the human brain, body temperature, metabolism, heart rate, sexual development, sleep and the body\'s use of fat and water are influenced by this region of the brain. This region of the brain is the:',
        options: ['hypothalamus', 'midbrain', 'corpus callosum', 'cerebellum'],
        answer: 0,
    },
    {
        question: 'In which cerebral lobes is the speech center located? Is it the:',
        options: ['frontal', 'parietal', 'temporal', 'occipital'],
        answer: 0,
    },
    {
        question: 'In most axons, the myelin sheath is interrupted at intervals of about 1 millimeter or more. These interruptions are called the:',
        options: ['glial', 'nodes of Ranvier (pron: ron-vee-ay)', 'collaterals', 'nodes of Babinet'],
        answer: 1,
    },    
    {
        question: 'This disease, caused by infection with the gram-negative Yersinia pestis, is transmitted by fleas from rats to humans What is the more common name for this disease?',
        options: ['Bubonic Plague','Food Poisoning','Leukemia','COVID-19'],
        answer: 0,
    },
    {
        question: 'In the mammalian body, this element plays many important roles. Try to identify this element with the fewest number of clues. This element is required to insure the integrity and permeability of cell membranes, to regulate nerve and muscle excitability, to help maintain normal muscular contraction, and to assure cardiac rhythmicity. It also plays a essential role in several of the enzymatic steps involved in blood coagulation and is the most important element of bone salt. Name this element.',
        options: ['Calcium', 'Potassium','Sodium','Magnesium'],
        answer: 0,
    },
    {
        question: 'What eight-letter name starting with the letter "O" is given to that branch of medical science concerned with the study of tumors?',
        options: ['Oncology','Optometry', 'Orthodontics', 'Opthamology'],
        answer: 0,
    },
    {
        question: 'In the more highly developed animals, such as humans this gas is used to regulate the activity of the heart, the blood vessels, and the respiratory system. WORKING MUSCLES PRODUCE A LARGE AMOUNT OF THIS SUBSTANCE. Narcosis due to this gas is characterized by mental disturbances which can include confusion, headache, low blood pressure and hypothermia. Name this gas.',
        options: ['Carbon Dioxide or CO2', 'Sulfur Dioxide or SO2', 'Oxygen, or O2', 'Hydrogen, or H2'],
        answer: 0,
    },
    {
        question: 'Cariology is the study of the:',
        options: ['human heart', 'tooth decay', 'kidneys', 'liver'],
        answer: 1,
    },
    {
        question: 'The larval form of butterflies and moths is more commonly known as what?',
        options: ['caterpillar', 'worm',  'moth', 'ovum'],
        answer: 0,
    },
    {
        question: 'Name the sac-like, blind pouch of the large intestine, situated below the level of the junction of the small intestine into the side of the large intestine. At the lower portion of this pouch one finds the appendix.',
        options: ['Cecum', 'Appendix', 'Small intestine', 'Large intestine'],
        answer: 0,
    },
    {
        question: 'During the final stage of cell division, the mitotic apparatus disappears, the chromosomes become attenuated, the centrioles duplicate and split, the nuclear membrane becomes reconstituted and the nucleolus reappears. This phase of cell division is known as:',
        options: ['prophase (pron: prO-phase)', 'metaphase', 'anaphase', 'telophase'],
        answer: 3,
    },
    {
        question: 'In cell division, the phase following the metaphase is known as:',
        options: ['prophase', 'anaphase', 'telophase', 'extophase'],
        answer: 1,
    },
    
    {
        question: 'The kinetic energy acquired by a mass (m) in traveling distance starting from rest under the action of constant force is directly proportional to?',
        options: ['1/m', 'm°', 'm', '1/√m'],
        answer: 1,
    },
    {
        question: 'The work done in moving a charge from one point to the other is 20 J. If the potential difference between the points is 10 V, the charge is?',
        options: ['4.0 C', '2.0 C', '0.5 C', '1.0 C'],
        answer: 1,
    },
    {
        question: 'Group of cells having a common origin and performing similar functions are called?',
        options: ['Tissues', 'Organs', 'Organ systems', 'None of the above'],
        answer: 0,
    },
    {
        question: 'A body of mass m moving with velocity 4 km/h collides with a body of mass 3 m at rest. Now the coalesced mass starts to move with a velocity of?',
        options: ['4 km/h', '4/3 km/h', '1 km/h', '2 km/h'],
        answer: 2,
    },
    {
        question: 'Which organ of the body is affected by Leukoderma?',
        options: ['Heart', 'Kidney', 'Lungs', 'Skin'],
        answer: 3,
    },
    {
        question: 'What is the third proportional to 9 and 12?',
        options: ['19', '16', '18', '17'],
        answer: 1,
    },
    {
        question: 'Which one of the following is an Enzyme?',
        options: ['Glucagon', 'Insulin', 'Somatropin', 'Trypsin'],
        answer: 3,
    },
    {
        question: 'A 5Ω resistance wire is doubled on it. Calculate the new resistance of the wire?',
        options: ['1.25Ω', '2.25Ω', '1.5Ω', '1.00Ω'],
        answer: 0,
    },
    {
        question: 'On applying a constant force to a body, it moves with uniform?',
        options: ['Momentum', 'Speed', 'Velocity', 'Acceleration'],
        answer: 3,
    },
    {
        question: 'The SI unit of electric charge is _______?',
        options: ['Wait', 'Ohm', 'Ampere', 'Coulomb'],
        answer: 3,
    },
    {
        question: 'If u = 0 m/s, a = 5 m/s^2 and t = 5 s then v = ?',
        options: ['10 m/s', '25 m/s', '10 m/s', '35 m/s'],
        answer: 1,
    },
    {
        question: 'The conversion of a solid directly into its vapour is called?',
        options: ['Evaporation', 'Condensation', 'Vaporisation', 'Sublimation'],
        answer: 3,
    },
    {
        question: 'Which of the following produces Testosterone in man?',
        options: ['Prostate gland', 'Scrotum', 'Testes', 'Vas deferens'],
        answer: 2,
    },
    {
        question: 'The sex of the children will be determined by what they inherit from the?',
        options: ['Nature', 'Father', 'Mother', 'Mother and Father'],
        answer: 1,
    },
    {
        question: 'A stone is tied to a spring balance. Under which of the following conditions will the reading on the spring balance show the least weight?',
        options: ['When the stone is partially submerged in the water in a beaker', 'When the stone is completely submerged in the water in a beaker', 'When the stone is on the surface of water taken in a beaker', 'When the stone is suspended in air'],
        answer: 1,
    },
    {
        question: 'Which of the following represents the equation for position-time relation?',
        options: ['2as = v^2 – u^2', 's = ut + 1/2at^2', 'v = u + at', 'V = u + at'],
        answer: 1,
    },
    {
        question: 'If the mass of a solid is doubled, its density?',
        options: ['Becomes two times', 'Becomes half', 'Remains unchanged', 'Becomes four times'],
        answer: 0,
    },
    {
        question: 'Fats and oils become rancid because of?',
        options: ['Transpiration', 'Reduction', 'Oxidation', 'Corrosion'],
        answer: 2,
    },
    {
        question: 'The forces between two bodies are always?',
        options: ['Unequal and in the opposite direction', 'Equal and in the opposite direction', 'Equal and in the same direction', 'Isolated forces'],
        answer: 1,
    },
    {
        question: 'Which of the following statements is true?',
        options: ['The Mass and weight of a body change from place to place', 'The Mass of a body remains the same while the Weight changes from place to place', 'The Mass of a body changes from place to place while the Weight remains the same', 'The Mass and Weight of the body remain the same in different places'],
        answer: 1,
    },
    {
        question: 'If u = 0 m/s, a = 5 m/s^2 and t = 5 s then v = ?',
        options: ['10 m/s', '25 m/s', '10 m/s', '35 m/s'],
        answer: 1,
    },
    {
        question: 'The SI unit of electric charge is _______?',
        options: ['Wait', 'Ohm', 'Amphere', 'Coulomb'],
        answer: 3,
    },
    {
        question: 'On applying a constant force to a body, it moves with uniform?',
        options: ['Momentum', 'Speed', 'Velocity', 'Acceleration'],
        answer: 3,
    },
   
],[
    {
        question: 'In Gymnosperms seeds are__________?',
        options: ['Always naked', 'Always covered', 'Naked in some and covered in others', 'Absent'],
        answer: 0,
    },
    {
        question: 'Which among the following is the first country to issue research licenses for human embryonic cloning to create stem cells?',
        options: ['United States', 'Australia', 'Germany', 'Britain'],
        answer: 3,
    },
    {
        question: 'Who among the following is best known for his discovery and development of the first safe and effective polio vaccine?',
        options: ['Jonas Salk', 'David Bodian', 'Almroth Wright', 'Albert Sabin'],
        answer: 0,
    },
    {
        question: 'Which among the following diseases is very rare in women compared to the men affected with the same disorder?',
        options: ['Osteoporosis', 'Color blindness', 'Nyctalopia', 'Down Syndrome'],
        answer: 1,
    },
    {
        question: 'The disorder “Pityriasis simplex capillitii ” is most commonly known as which among the following?',
        options: ['Tulip fingers', 'Dandruff', 'Baldness', 'Eczema'],
        answer: 1,
    },
    {
        question: 'Two vectors are said to be equal if:',
        options: ['they have equal magnitude and same direction', 'they have equal magnitude and opposite direction', 'they have equal magnitude and common initial point', 'they have equal magnitude irrespective of the direction'],
        answer: 0,
    },
    {
        question: 'Which of the following is correct about the value of acceleration due to gravity?',
        options: ['it is greater at mountains than in plains', 'it is lesser at mountains than in plains', 'it is equal for mountains and plains', 'None of the above'],
        answer: 1,
    },
    {
        question: 'The time period of a satellite does not depend on which of the following?',
        options: ['Radius of earth', 'Height of the satellite', 'Mass of the satellite', 'None of the above'],
        answer: 2,
    },
    {
        question: 'What do we call the distance of particle from the mean position at that instant in S.H.M?',
        options: ['Distance', 'Displacement', 'Phase', 'Angular frequency'],
        answer: 1,
    }, 
    {
     question: 'Which of the following law states that if two systems are in thermal equilibrium with a third system separately, then they are in thermal equilibrium with each other?',
        options: ['First law of Thermodynamics', 'Zeroth law of Thermodynamics', 'Second law of Thermodynamics', 'Third law of Thermodynamics'],
        answer: 1,
    },
    {
        question: 'Which of the following acts as anode in a mercury cell?',
        options: ['paste of HgO and carbon', 'zinc – mercury amalgam', 'Copper and iron rod', 'None of the above'],
        answer: 1,
    },
    {
        question: 'Which of these is not an addition polymer?',
        options: ['PVC', 'Nylon 66', 'Polypropylene', 'All of the above'],
        answer: 1,
    },
    {
        question: 'Which of the following is the method to get rid of temporary hardness of water?',
        options: ['Boiling the water', 'Addition of calcium hydroxide', 'Both a and b', 'None'],
        answer: 2,
    },
    {
        question: 'Which base is present in milk of magnesia?',
        options: ['Calcium hydroxide', 'Ammonium hydroxide', 'Magnesium hydroxide', 'Sodium hydroxide'],
        answer: 2,
    },
    {
        question: 'Which one of the following cultivation is related to Floriculture?',
        options: ['Cultivation of Vegetables and Fruits', 'Cultivation and Study of Ornamental Flowers', 'Cultivation of crops', 'None of these'],
        answer: 1,
    },
    {
        question: 'Who among the following was awarded the Nobel Prize in Medicine in 1926 for his contribution to cancer research?',
        options: ['Christiaan Eijkman', 'Johannes Fibiger', 'Julius Wagner-Jauregg', 'Charles-Jules-Henri Nicolle'],
        answer: 1,
    },
    {
        question: '___ is the product of aerobic respiration.',
        options: ['Malic acid', 'Pyruvate', 'Ethylene', 'Lactose'],
        answer: 0,
    },
    {
        question: 'The material covering the bones of reptiles is?',
        options: ['Calcium', 'Chitin', 'Keratin', 'None'],
        answer: 2,
    },
    {
        question: 'Heloderma stapecutm is a __',
        options: ['Iguanas', 'Gecko', 'Venomous lizard', 'Chameleon'],
        answer: 2,
    },
    {
        question: 'What are the symptoms of suffering from kidney disease?',
        options: ['High blood pressure', 'Respiration problem', 'Swelling on the face, legs, etc.', 'All of the above'],
        answer: 3,
    },
    {
        question: 'Filariasis is caused by __.',
        options: ['roundworms', 'pinworm', 'hookworm', 'none of these'],
        answer: 0,
    },
    {
        question: 'The flagellated cells that line the spongiocoel in poriferans are called__.',
        options: ['ostia', 'mesenchymal cells', 'choanocytes', 'oscula'],
        answer: 2,
    },
    {
        question: 'What is the shell of a mollusk produced by?',
        options: ['Radula', 'Thorax', 'Mantle', 'Abdomen'],
        answer: 2,
    },
    {
        question: 'Cows belong to which of the following order?',
        options: ['Proboscidea', 'Notoryctemorphia', 'Artiodactyla', 'Paucituberculata'],
        answer: 2,
    },
    {
        question: 'What is the name of the smallest muscle?',
        options: ['Gutters Maximus', 'Antagonists', 'Stapedius', 'None of the above'],
        answer: 2,
    },
    {
        question: 'This plasma protein is responsible for blood clotting:',
        options: ['Fibrinogen', 'Globulin', 'Serum amylase', 'Albumin'],
        answer: 0,
    },
    {
        question: 'Which systems protect our body against disease-causing microbes?',
        options: ['Immune system', 'Digestive system', 'Excretory system', 'Respiratory system'],
        answer: 0,
    },
    {
        question: 'A process where new combinations of alleles are formed is called?',
        options: ['Genetic Drift', 'Mutation', 'Genetic Recombination', 'Natural selection'],
        answer: 2,
    },
    {
        question: 'Jaws are absent in ____:',
        options: ['Birds', 'Fishes', 'Reptiles', 'Protochordata'],
        answer: 3,
    },
    {
        question: 'What is Bt cotton?',
        options: ['cloned plant', 'transgenic plant', 'hybrid plant', 'mutated plant'],
        answer: 1,
    },
    {
        question: 'The ____ is the stem-like part of the leaf that joins the blade to the stem, is known as:',
        options: ['Vein', 'Petiole', 'Stipules', 'Midrib'],
        answer: 1,
    },
    {
        question: 'Which of the following is an example of parasitic algae?',
        options: ['Ulothrix', 'Cephaleuros', 'Oedogonium', 'Sargassum'],
        answer: 1,
    },
    {
        question: 'Insulin is a kind of ____:',
        options: ['Hormone', 'Enzyme', 'Protein', 'Vitamin'],
        answer: 0,
    },
    {
        question: 'Natural system of classification was proposed by ____ botanists:',
        options: ['German', 'Swedish', 'Indian', 'British'],
        answer: 3,
    },
    {
        question: 'The five kingdom concept of classification of organisms was given by ____:',
        options: ['Charles Darwin', 'Carl Woese', 'William Paley', 'Robert Whittaker'],
        answer: 3,
    },
    {
        question: 'Bulbils takes part in ____:',
        options: ['Respiration', 'Sexual reproduction', 'Food storage', 'Vegetative reproduction'],
        answer: 3,
    },
    {
        question: 'Which of the following metals causes Itai-Itai disease?',
        options: ['Cadmium', 'Chromium', 'Cobalt', 'Copper'],
        answer: 0,
    },
    {
        question: 'The inert gas used as a beacon light is:',
        options: ['Kr', 'Ar', 'He', 'Ne'],
        answer: 3,
    },
    {
        question: 'Inert gases are:',
        options: ['Miscible with water', 'Not stable', 'Chemically unreactive', 'Chemically very active'],
        answer: 2,
    },
    {
        question: 'Xerophthalmia is caused due to the deficiency of vitamin _____:',
        options: ['A', 'C', 'D', 'K'],
        answer: 0,
    },
    {
        question: 'Which of the following is not a symptom of Wilsons disease?',
        options: ['Fluid build-up in the legs or abdomen', 'Uncontrolled movements or muscle stiffness', 'Problems with speech, swallowing or physical coordination', 'Night blindness'],
        answer: 3,
    },
    {
        question: 'Nucleus of an atom consists of:',
        options: ['Proton', 'Neutron', 'Proton and Neutron', 'Electron, Proton and Neutron'],
        answer: 2,
    },
    {
        question: 'Iron rusts quickly in:',
        options: ['Rain water', 'Sea water', 'Distilled water', 'River water'],
        answer: 1,
    },
    {
        question: 'Ferrous sulphate is used in water treatment as a/an:',
        options: ['Oxidizing agent', 'Reducing agent', 'Coagulant aid', 'Adsorbent'],
        answer: 2,
    },
    {
        question: 'Which of the following is also used as a Bio fertilizer?',
        options: ['Urea', 'Ammonia', 'Uric Acid', 'Nitrates'],
        answer: 1,
    },
    {
        question: 'Combustion of a candle is a/an:',
        options: ['photochemical reaction', 'physical change', 'endothermic reaction', 'exothermic reaction'],
        answer: 3,
    },
    {
        question: 'Particulates (<1 µm size) remaining suspended in air indefinitely and transported by wind currents are called:',
        options: ['Mists', 'Fumes', 'Aerosols', 'Smoke'],
        answer: 2,
    },
    {
        question: 'Tartaric Acid is not found in:',
        options: ['Tamarind', 'Grapes', 'Unripe mangoes', 'Spinach'],
        answer: 3,
    },
    {
        question: 'Which of the following is the cleanest source of energy?',
        options: ['Biofuel', 'Fossil fuel', 'Nuclear power', 'Wind energy'],
        answer: 3,
    },
]];